PETE ZAH LEGENDS — FULL PORTAL STARTER

Files:
- index.html — website, original built-in mini-games, search/categories, social/app panel.

Publish free with GitHub Pages:
1. Download and extract this ZIP.
2. Sign in at https://github.com and create a public repository named pete-zah-legends.
3. Upload index.html to the repository root and commit.
4. Go to Settings > Pages. Choose Deploy from a branch, select main and / (root), and save.
5. Wait for GitHub Pages to publish and use the URL shown in Settings > Pages.

Notes:
- Built-in games are original mini-games; Neon Moto Stunt is an original simple motorcycle game, not Moto X3M.
- Social apps are offered in an embedded panel where supported, but many sites block iframes or require their own app/login. A new-tab fallback is provided.
- Embedding does not bypass school filters. School network restrictions still apply.
- GitHub Pages for public repositories is free. Never put private details or passwords in public files.
